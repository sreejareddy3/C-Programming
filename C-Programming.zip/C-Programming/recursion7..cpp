#include<stdio.h>
int sum(int);
main()
{
	int n,x;
	printf("Enter number\n");
	scanf("%d",&n);
	x=sum(n);
    printf("Sum=%d",x);
}
int sum(int n)
{
	if(n==0)
	return;
	else
	{
		return(n%10*10+sum(n/10));
	}
}
