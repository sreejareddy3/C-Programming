#include<stdio.h>
main()
{
	int a,b,c;
	printf("Enter three numbers\n");
	scanf("%d %d %d",&a,&b,&c);
	if(a>c)
	{
		if(a>b)
		{
			printf("a is greater");
		}
		else
		{
			printf("b is greater");
		}
    }
    else
    {
    	if(b>c)
    	{
    		printf("b is greater");
		}
		else
		{
			printf("c is greater");
		}
	}
}
