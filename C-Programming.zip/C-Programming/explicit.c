#include<stdio.h>
main()
{
	int m1,m2,m3,m4;
	printf("enter the marks\n");
	scanf("%d %d %d %d",&m1,&m2,&m3,&m4);
	float result;
	result=(float)(m1+m2+m3+m4)/5;
	printf("result=%f\n",result);
	printf("m1=%d",m1);
}
