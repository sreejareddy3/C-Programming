#include<stdio.h>
main()
{
	int n,rev=0,x;
	printf("enter a number\n");
	scanf("%d",&n);
	for(rev=0;n>0;n=n/10)
	{
		x=n%10;
		rev=(rev*10)+x;
	}
	printf("The reverse of the number is %d",rev);
}
