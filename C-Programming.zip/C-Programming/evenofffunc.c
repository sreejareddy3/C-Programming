#include<stdio.h>
void even(int,int[]);
void odd(int,int[]);
main()
{
	int n,i,c[10],k,j,a[10],b[10],flag=0,flag1=0;
	printf("Enter no.of elements\n");
	scanf("%d",&n);
	printf("Enter elements\n");
	for(i=0;i<n;i++)
	scanf("%d",&c[i]);
	for(i=0;i<n;i++)
	{
		if(c[i]%2==0)
		flag++;
		else
		flag1++;
	}
	for(i=0;i<n;i++)
	{
	if(c[i]%2==0)
	{
      even(flag,c);
    }
    else
    {
      odd(flag1,c);
	}
}
}
void even(int n,int c[])
{
	int i,j=0,a[10];
	for(i=0;i<n;i++)
	{
		a[j]=c[i];
		j++;
	}
	for(j=0;j<n;j++)
	printf("%3d",a[j]);
	printf("\n");
}
void odd(int n,int c[])
{
	int b[10];
	int i,j=0,flag;
	for(i=0;i<n;i++)
	{
		b[j]=c[i];
		j++;
	}
	for(j=0;j<n;j++)
	printf("%3d",b[j]);
}
