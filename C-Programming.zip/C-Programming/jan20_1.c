#include<stdio.h>
#include<string.h>
main()
{
	float salary;
	float gender;
	printf("Enter the salary\n");
	printf("Enter the gender\n1 if male\n 2 if female");
	scanf("%f %f",&salary,&gender);
	if(gender==1)
	{
		float bonus=(0.05)*salary;
		printf("Salary with bonus is %f",bonus+salary);
	}
	else
	{
		float bonus1=(0.1)*salary;
		printf("Salary with bonus is %f",bonus1+salary);
	}
}
