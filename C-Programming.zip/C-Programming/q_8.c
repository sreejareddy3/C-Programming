#include<stdio.h>
main()
{
	int *p,i,n;
	printf("Enter n value:");
	scanf("%d",&n);
	p=(int *)calloc(n,sizeof(int));
	printf("Enter values\n");
	for(i=0;i<n;i++)
	scanf("%d",p+i);
	for(i=0;i<n;i++)
	printf("%3d",*(p+i));
	free(p);
}
