#include<stdio.h>
#include<string.h>
int palindrome(char []);
main()
{
	char a[50];
	int z;
	gets(a);
    z=palindrome(a);
    if(z==0)
    printf("Palindrome");
    else
    printf("Not a Palindrome");
}
int palindrome(char a[])
{
	int i,l=0,flag=0,j=0;
	char b[50];
	for(i=0;a[i]!='\0';i++)
	l++;
	for(i=l-1;i>=0;i--)
	{
		b[j]=a[i];
		j++;
	}
	b[j]='\0';
	for(i=0;i<l;i++)
	{
		if(a[i]!=b[i])
		{
			flag=1;
			break;
		}
	}
   return flag;
}
