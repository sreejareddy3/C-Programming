#include<stdio.h>
 main()
{
  float a,b;
  printf("enter the height and baseof the triangle");
  scanf("%f %f ",&a,&b);
  float area=0.5*a*b;
  //int perimeter=4*a;
  printf("area=%f",area);
}
