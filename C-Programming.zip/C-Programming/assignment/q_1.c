#include<stdio.h>
#include<stdlib.h>
main()
{
	char c;
	FILE *fp;
	printf("Enter File data:");
	fp=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/file1.txt","a");
	while((c=getchar())!=EOF)
    putc(c,fp);
    fclose(fp);
	fp=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/file1.txt","r");
	printf("Data in File:");
	while((c=getc(fp))!=EOF)
    putchar(c);	
    fclose(fp);
}
