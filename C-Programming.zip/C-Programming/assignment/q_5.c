#include<stdio.h>
#include<stdio.h>
struct elcbill 
{
	char fname[50];
	char lname[50];
	float pvu;
	float psu;
	float total;
};
main()
{
	struct elcbill s[10];
	int n,i;
	printf("enter n value:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	
	printf("Enter first name:");
	scanf("%s",s[i].fname);
	printf("Enter last name:");
	scanf("%s",s[i].lname);
	printf("Enter your previous units consumed:");
	scanf("%f",&s[i].pvu);
	printf("Enter your present units consumed:");
	scanf("%f",&s[i].psu);
	float amt=s[i].pvu-s[i].psu;
	if(amt>=0 && amt<=100)
	amt=amt*0.80;
    else if(amt>100 && amt<=200)
	amt=amt*0.90;
    else if(amt>200 && amt<=300)
	amt=amt*1.0;
    else
	amt=amt*2.0;
	s[i].total=amt+100;
}
printf("--------------------------Elctricity Bill--------------------------");
printf("\nFirst Name\tLast Name\tPrevious Units\tpresent Units\tTotal\n");
for(i=0;i<n;i++)
{
    printf("%s\t\t%s\t\t%f\t%f\t%f",s[i].fname,s[i].lname,s[i].pvu,s[i].psu,s[i].total);
}
}

