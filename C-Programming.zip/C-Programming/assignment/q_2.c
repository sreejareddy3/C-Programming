#include<stdio.h>
#include<stdlib.h>
main()
{
	char c;
	FILE *fp,*fp1;
	printf("Enter File data:");
	fp=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/file2.txt","w");
	while((c=getchar())!=EOF)
    putc(c,fp);
    fclose(fp);
	fp1=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/file3.txt","w");
	fp=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/file2.txt","r");
	while((c=getc(fp))!=EOF)
    putc(c,fp1);	
    fclose(fp);
    fclose(fp1);
    fp1=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/file3.txt","r");
    printf("Copied Data:");
    while((c=getc(fp1))!=EOF)
    putchar(c);
    fclose(fp1);
}
