#include<stdio.h>
#include<stdlib.h>
main()
{
	char c;
	FILE *fp1,*fp2,*fp3;
	printf("Enter File1 data:");
	fp1=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/merge1.txt","w");
	while((c=getchar())!=EOF)
    putc(c,fp1);
    fclose(fp1);
    printf("Enter File1 data:");
	fp2=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/merge2.txt","w");
	while((c=getchar())!=EOF)
    putc(c,fp2);
    fclose(fp2);
	fp1=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/merge1.txt","r");
	fp2=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/merge2.txt","r");
	fp3=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/merge3.txt","w");
	while((c=getc(fp1))!=EOF)
    putc(c,fp3);
	while((c=getc(fp2))!=EOF)
    putc(c,fp3);	
    fclose(fp1);
    fclose(fp2);
    fclose(fp3);
    fp3=fopen("C:/Users/pramo/OneDrive/Desktop/assignment/merge3.txt","r");
    while((c=getc(fp3))!=EOF)
    putchar(c);	
    fclose(fp3);
}
