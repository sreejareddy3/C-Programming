#include<stdio.h>
struct employee
{
	char name[50];
	int id;
	int salary;
};
main()
{
	struct employee e[10],*p;
	p=&e;
	int n,i;
	printf("enter n value:");
	scanf("%d",&n);
	printf("Enter employee Details:");
	for(i=0;i<n;i++)
	scanf("%s%d%d",(p+i)->name,&(p+i)->id,&(p+i)->salary);
	printf("------------------------Employee Details----------------------\n");
	printf("Name\tId\tSalary\n");
	for(i=0;i<n;i++)
	printf("%s\t%d\t%d\n",(p+i)->name,(p+i)->id,(p+i)->salary);
}
