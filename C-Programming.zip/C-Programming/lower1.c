#include<stdio.h>
#include<string.h>
main()
{
	char str[50];
	printf("Enter String\n");
	gets(str);
	int i=0;
	if(str[i]<96)
	{
	printf("String in Lower case\n");
	for(i=0;str[i]!='\0';i++)
	printf("%c",str[i]+32);
    }
    else
    {
    printf("String in Upper case\n");
   	for(i=0;str[i]!='\0';i++)
	printf("%c",str[i]-32);
	}	
}
