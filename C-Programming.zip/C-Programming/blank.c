#include<stdio.h>
#include<string.h>
main()
{
	char str[50],i,j;
	printf("Enter String\n");
	gets(str);
	for(i=0;str[i]!='\0';i++)
	{
		if(str[i]==32)
		{
			if(str[i+1]==32)
			{ 
				for(j=i+1;str[j]!='\0';i++)
				{
					str[j]=str[j+1];
					j++;
				}
			}
		}
	}
	puts(str);
}
