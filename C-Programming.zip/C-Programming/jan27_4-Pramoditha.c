#include<stdio.h>
main()
{
	int n,rev=0,x;
	printf("enter a number\n");
	scanf("%d",&n);
	do
	{
		x=n%10;
		rev=(rev*10)+x;
		n=n/10;
	}while(n>0);
	printf("The reverse of the number is %d",rev);
}
