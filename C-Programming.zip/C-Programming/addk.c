extern int a,b;
add1()
{
   printf("Result=%d",a+b);	
}
