#include<stdio.h>
void even(int,int[]);
void odd(int,int[]);
main()
{
	int i,n,m,c[i],flag,flag1;
	printf("enter no.of elements");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&c[i]);
	}
	
		if(m%2==0)
		{
			flag++;
		}
		else
		{
			flag1++;
		}
		if(m%2==0)
		{
			even(flag,c[i]);
		}
		else
		{
			odd(flag1,c[i]);
		}
	}	
void even(int n,int c[])
{
	int i,j=0,a[10];
	for(i=0;i<n;i++)
	{
	a[j]=c[i];
	j++;
   }
   for(j=0;j<n;j++)
   printf("%d",a[j]);
}
void odd(int n,int c[])
{
	int i,j=0,a[10];
	for(i=0;i<n;i++)
	{
	a[j]=c[i];
	j++;
   }
   for(j=0;j<n;j++)
   printf("%d",a[j]);
}
