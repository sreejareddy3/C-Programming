#include<stdio.h>
main()
{
	int time;
	printf("Enter the working time\n");
	scanf("%d",&time);
	int pay=time*50;
	if(time<=40)
	{
		printf("Pay is %d",pay);
	}
	else
	{
		int overtime=time-40;
		int opay=(40*50)+(overtime*62);
		printf("Pay is %d",opay);
	}
}
