#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p,str[50];
	int n1,n2,i,j=0,flag=0;
	printf("Enter size:");
	scanf("%d",&n1);
	p=(char *)malloc(n1*sizeof(char));
	for(i=0;i<=n1;i++)
	scanf("%c",p+i);
	printf("%c",*(p));
   for(i=0;i<=n1;i++)
	{
		for(j=n1-1;j>=0;j--)
		{
	//	printf("%c\n",*(p+i));
	//	printf("%c",*(p+j));
		if(*(p+i)!=*(p+j))
		{
			flag=1;
		    break;
		}
	}
    }
	if(flag==0)
	printf("Palindrome");
	else
	printf("Not a Palindrome");
	flag=0,j=0;
	char str1[50];
	printf("\nEnter new size:");
	scanf("%d",&n2);
	p=(char *)realloc(p,n2*sizeof(char));
	for(i=0;i<n2;i++)
	scanf("%c",p+i);
	for(i=n2-1;i>=0;i--)
	{
	str1[j]=*(p+i);
	j++;
    }
    str1[j]='\0';
    p++;
   for(i=0;*(p+i)!='\0';i++)
	{
		if(*(p+i)!=str1[i])
		{
			flag=1;
		    break;
		}
	}
	if(flag==0)
	printf("Palindrome");
	else
	printf("Not a Palindrome");
	free(p);
}
