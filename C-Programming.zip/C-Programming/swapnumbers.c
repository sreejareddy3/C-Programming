#include<stdio.h>
main()
{
  int a,b,c;
  printf("enter two values\n");
  scanf("%d %d",&a,&b);
  printf("a=%d b=%d\n",a,b);
  c=a;
  a=b;
  b=c;
  printf("a=%d b=%d",a,b);
}
