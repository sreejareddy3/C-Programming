#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    int f1=0,f2=1,n,sum=0,i;
    scanf("%d",&n);

    for(i=1;i<n;i++)
    {
       sum=f1+f2;
       f1=f2;
       f2=sum;
    }
    
        printf("%d",sum);
    
    return 0;
}
