#include<stdio.h>
main()
{
	int *p1,p,fact=1,*fact1,i=1;
	p1=&p;
	fact1=&fact;
	printf("Enter number\n");
	scanf("%d",p1);
	while(i<*p1)
	{
		*fact1=*fact1+*fact1*i;
		i++;
	}
	printf("Factorial=%d",*fact1);
	
}
