#include<stdio.h>
#include<string.h>
main()
{
  char str1[10],str2[10];
  printf("enter any string\n");
  gets(str1);
  strcpy(str2,str1);
  int x;
  x=strcmp(str2,strrev(str1));
  if(x==0)
  printf("Palindrome");
  else
  printf("Not a palindrome");
}
