#include<stdio.h>
int add(int,int);
int sub(int,int);
int mul(int,int);
float div(int,int);

main()
{
	int ch;
	int a,b,c;
	float d;
	char t;
	do
	{
	printf("Press:1 for addition\n2 for subtraction\n3 for multiplication\n4 for division\n");
	printf("Enter the arithmatic operator\n");
	scanf("%d",&ch);
	printf("Enter two numbers\n");
	scanf("%d %d",&a,&b);
	switch(ch)
	{
		case 1:c=add(a,b);
		         printf("The result is %d",c);
		         break;
		case 2:c=sub(a,b);
		         printf("The result is %d",c);
		         break;  
		case 3:c=mul(a,b);
		         printf("The result is %d",c);
		         break;		
		case 4:d=div(a,b);
		         printf("The result is %f",d);
		         break;		         
	}
	printf("\nPress y to continue");
    scanf(" %c",&t);
    }while(t=='y');	
}
int add(int a,int b)
{
	return a+b;
}
int sub(int a,int b)
{
	return a-b;
}
int mul(int a,int b)
{
	return a*b;
}
float div(int a,int b)
{
	float c;
	c=(float)(a)/(float)(b);
	return c;
}
