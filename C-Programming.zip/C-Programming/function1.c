#include<stdio.h>
int sum(int,int);
int sub(int,int);
int mul(int,int);
float div(int,int);
main()
{
	int a,z,a1,a2;
	float z1;
	printf("Enter\n1.sum\n2.subtraction\n3.multiplication\n4.division\n");
	scanf("%d",&a);
	printf("Enter values");
	scanf("%d %d",&a1,&a2);
	switch(a)
	{
		case 1:z=sum(a1,a2);
		printf("Result=%d",z);
		break;
		case 2:z=sub(a1,a2);
		printf("Result=%d",z);
		break;
		case 3:z=mul(a1,a2);
		printf("Result=%d",z);
		break;
		case 4:z=div(a1,a2);
		printf("Result=%f",z1);
		break;
	}
}
int sum(int x,int y)
{
	int sum1=x+y;
	return sum1;
}
int sub(int x,int y)
{
	int sub1=x-y;
	return sub1;
}
float div(int x,int y)
{
	float div1=(float)(x)/(float)(y);
	return div1;
}
int mul(int x,int y)
{
	int mul1=x*y;
	return mul1;
}
