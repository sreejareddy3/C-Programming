#include<stdio.h>
main()
{
	int a,b,c,d;
	printf("enter three numbers\n");
	scanf("%d %d %d",&a ,&b, &c);
	printf("%d %d %d\n",a ,b, c);
	d=a,a=b,b=c,c=d;
    printf("%d %d %d",a ,b, c);
}
