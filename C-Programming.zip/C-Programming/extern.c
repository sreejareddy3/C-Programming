#include<stdio.h>
#include"add.c"
#include"sub.c"
#include"mul.c"
#include"div.c"
int a,b;
main()
{
	int ch;

	char t;
	do
	{
	printf("Press:1 for addition\n2 for subtraction\n3 for multiplication\n4 for division\n");
	printf("Enter the arithmatic operator\n");
	scanf("%d",&ch);
	printf("Enter two numbers\n");
	scanf("%d %d",&a,&b);
	switch(ch)
	{
		case 1:add1(a,b);
		         break;
		case 2:sub1(a,b);
		         break;  
		case 3:mul1(a,b);
		         break;		
		case 4:div1(a,b);
		         break;	
	}
	printf("\nPress y to continue");
    scanf(" %c",&t);
    }while(t=='y');		         
}
