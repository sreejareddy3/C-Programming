#include<stdio.h>
main()
{
	float m1,m2,m3,t;
	printf("Enter the marks in maths physics and chemistry\n");
	scanf("%f %f %f",&m1,&m2,&m3);
	t=m1+m2+m3;
	float t1=m1+m2;
	if(m1>=65 && m2>=55 && m3>=50)
	{
		if(t>=180 || t1>=140)
		{
			printf("The candidate is eligible fr admission");
		}
	}
	else
	{
		printf("The candidate is not eligible");
	}
}
