#include<stdio.h>
#include<stdlib.h>
main()
{
	char c;
	FILE *f1,*f2,*f3;
	f1=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/co1.txt","w");
	f2=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/co2.txt","w");
	printf("Enter file 1 Data\n");
	while((c=getchar())!=EOF)
	putc(c,f1);
	printf("Enter file 2 Data\n");
	while((c=getchar())!=EOF)
	putc(c,f2);
	fclose(f1);
	fclose(f2);
	f1=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/co1.txt","r");
	f2=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/co2.txt","r");
	f3=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/co3.txt","w");
	while((c=getc(f1))!=EOF)
	putc(c,f3);
	while((c=getc(f2))!=EOF)
	putc(c,f3);
	fclose(f1);
	fclose(f2);
	fclose(f3);
	f3=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/co3.txt","r");
	printf("\nData in file 3");
	while((c=getc(f3))!=EOF)
	putchar(c);
	fclose(f3);
}
