#include<stdio.h>
#include<stdlib.h>
main()
{
	char c;
	FILE *f1;
	printf("Enter File Data\n");
	f1=fopen("C:/Users/pramo/OneDrive/Desktop/IP/file.txt","w");
	while((c=getchar())!=EOF)
	putc(c,f1);
	fclose(f1);
	f1=fopen("C:/Users/pramo/OneDrive/Desktop/IP/file.txt","r");
	while((c=getc(f1))!=EOF)
	putchar(c);
	fclose(f1);
}
