#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p,*p1,str[100];
	int n1,n2,n3,n4,i,j,l=0;
	printf("enter size of first string:");
	scanf("%d",&n1);
	p=(char *)malloc(n1*sizeof(char));
	printf("enter the string:");
	for(i=0;i<n1;i++)
	scanf("%c",p+i);
	printf("enter size of second string:");
	scanf("%d",&n2);
	p1=(char *)malloc(n2*sizeof(char));
	printf("enter the string:");
	for(i=0;i<n2;i++)
	scanf("%c",&str[i]);
	for(i=1;str[i]!='\0';i++)
	l++;
	for(i=1;*(p+i)!='\0';i++)
	{
		str[l]=*(p+i);
		l++;
	}
	str[l]='\0';
	puts(str);
	printf("\nenter resize:");
	scanf("%d",&n3);
	p=(char *)realloc(p,n3*sizeof(char));
	printf("enter the string:");
	for(i=0;i<n3;i++)
	scanf("%c",p+i);
	printf("enter size of second string:");
	scanf("%d",&n4);
	p1=(char *)realloc(p1,n4*sizeof(char));
	printf("enter the string:");
	for(i=0;i<n4;i++)
	scanf("%c",&str[i]);
	for(i=1;str[i]!='\0';i++)
	l++;
	for(i=1;*(p+i)!='\0';i++)
	{
		str[l]=*(p+i);
		l++;
	}
	str[l]='\0';
	puts(str);
	free(p);
	free(p1);
}
