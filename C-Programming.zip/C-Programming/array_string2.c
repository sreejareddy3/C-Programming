#include<stdio.h>
#include<string.h>
int length(char []);
main()
{
	int z;
	char a[50];
	printf("Enter String\n");
	gets(a);
	z=length(a);
	printf("Length=%d",z);
}
int length(char a[])
{
	int i,l=0;
	for(i=0;a[i]!='\0';i++)
	l++;
	return l;
}


