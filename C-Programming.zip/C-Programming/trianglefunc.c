#include<stdio.h>
int i,j;
void lowert(int,int,int [][10]);
void uppert(int,int,int [][10]);
main()
{
	int a[10][10],i,n,m,j;
	printf("enter order\n");
	scanf("%d %d",&m,&n);
	printf("enter elements\n");
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	scanf("%d",&a[i][j]);
    }
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	printf("%3d",a[i][j]);
	printf("\n");
    } 
    uppert(m,n,a);
    lowert(m,n,a);
}
void lowert(int m,int n,int a[][10])
{
	printf("Lower Triangle\n");
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	{
	if(i>=j)
	printf("%3d",a[i][j]);
    }        
	printf("\n");
    } 
}
void uppert(int m,int n,int a[][10])
{
	printf("Upper Triangle\n");
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	printf("%3d",a[i][j]);
    printf("\n");
    n--;
    }
} 
