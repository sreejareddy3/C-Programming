#include<stdio.h>
main()
{
	int count=0,i,i1,a[20],x[20],j=0,n,flag=2;
	printf("Enter n value\n");
	scanf("%d",&n);
	printf("enter your range\n");
	for(i=0;i<n;i++)
	{
	scanf("%d",&x[i]);
    }
	for(i=0,i1=1;i1<=x[i];i1++)
	{
		if(x[i]%i1==0)
		{
		 count=0;
		 count++;
       	}
       	if(count==2)
       	{
       	 a[j]=x[i];
	     j++;
		}
    }
   // printf("%d",flag);
    for(j=0;j<flag;j++)
    printf("%3d",a[j]);
}
