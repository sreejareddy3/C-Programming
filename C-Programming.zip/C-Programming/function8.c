#include<stdio.h>
void line(int);
main()
{
	int n;
	printf("Enter n value\n");
	scanf("%d",&n);
	line(n);
}
void line(int n)
{
	int i=1,k,c=1;
	while(i<=n)
	{
		while(k<=3)
		{
			printf("%3d",c);
			c++;
			k++;
		}
		k=1;
		printf("\n");
		i++;
	}
}
