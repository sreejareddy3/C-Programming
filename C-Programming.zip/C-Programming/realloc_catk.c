#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p2,*p1;
	int np11,np12,np21,np22,i,l1=0,l2=0,flag=0;
	printf("Enter size of 1st string:");
	scanf("%d",&np11);
	p1=(char *)malloc(np11*sizeof(char));
	printf("Enter String:");
	for(i=0;i<=np11;i++)
	scanf("%c",p1+i);
	printf("Enter size of 2nd string:");
	scanf("%d",&np21);
	p2=(char *)malloc(np21*sizeof(char));
	printf("Enter String:");
	for(i=0;i<=np21;i++)
	scanf("%c",p2+i);
    for(i=0;i<=np11;i++)
	*(p2+np21+i)=*(p1+i);
	for(i=0;i<=np11+np21+1;i++)
	printf("%c",*(p2+i));
	printf("\nEnter new size of 1st string:");
	scanf("%d",&np12);
	p1=(char *)realloc(p1,np12*sizeof(char));
	printf("Enter String:");
	for(i=0;i<=np12;i++)
	scanf("%c",p1+i);
	printf("Enter new size of 2st string:");
	scanf("%d",&np22);
	p2=(char *)realloc(p2,np22*sizeof(char));
	printf("Enter the String:");
	for(i=0;i<=np22;i++)
	scanf("%c",p2+i);
		if(np12==np22)
	{
		for(i=0;i<np22;i++)
		{
			if(*(p1+i)!=*(p2+i))
			{
			flag=1;
			break;
		   }
		}
	}
	else
	flag=1;
	if(flag==0)
	printf("same");
	else 
	printf("not same");
	free(p1);
	free(p2);
}
