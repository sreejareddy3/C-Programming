#include<stdio.h>
int tiffin(int,int);
int snacks(int,int);
int meals(int,int);
main()
{
  int x,y,z,a1,z1;
  printf("1.tiffin\n2.snacks\n3.meals\n\n");
  printf("1.idly\n2.dosa\n3.wada\n\n");
  printf("1.pizza\n2.burger\n\n");
  printf("1.veg\n2.non veg\n\n");
  printf("type of item: ");
  scanf("%d",&x);
  printf("type of food: ");
  scanf("%d",&y);
  printf("no of plates: ");
  scanf("%d",&z);
  switch(x)
  {
  	case 1:z1=tiffin(y,z);
  	printf("Amount=%d",z1);
  	break;
	case 2:z1=snacks(y,z);
	printf("Amount=%d",z1);
	break;
    case 3:z1=meals(y,z);
    printf("Amount=%d",z1);
    break;	
}
}
int tiffin(int y,int z)
{  
    int a;   
    switch(y)
    {
  	case 1:a=z*10;
	break;
	case 2:a=z*5;
  	break;
    case 3:a=z*20;
	break;
    }
	return a;
}
int snacks(int y,int z)
 {
 	int a;
    switch(y)
    {
 	case 1:a=z*100;
	break;
	case 2:a=z*250;
  	break;
    }
    return a;
 }
int meals(int y,int z)
 {
 	int a;
 	switch(y)
   {
   	  case 1:a=z*50;
	  break;
	  case 2:a=z*100;
  	  break;
    }
    return a;
 }
