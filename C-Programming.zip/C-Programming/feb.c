#include<stdio.h>
#include<math.h>
main()
{
	int n,sum=0,i;
	printf("Enter a value\n");
	scanf("%d",&n);
	for(i=1;n<=i;i++)
	{
      sum=sum+pow(i,i);
	}
	printf("sum of series=%d\n",sum);
}

