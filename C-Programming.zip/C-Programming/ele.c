#include<stdio.h>
struct electricity_bill
{
	char first_name[10];
	char last_name[10];
	float previous_units;
	float present_units;
	float total;
};
main()
{
	struct electricity_bill p[10];
	int n,i;
	printf("Enter Size:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	printf("enter first name:");
	scanf("%s",p[i].first_name);
	printf("enter lastname:");
	scanf("%s",p[i].last_name);
	printf("enter previous units consumed:");
	scanf("%f",&p[i].previous_units);
	printf("enter present units consumed:");
	scanf("%f",&p[i].present_units);
    }
    printf("--------------------Electricity Bill-----------------------------");
	printf("\nFirst Name\tLast Name\tPrevious Units\t\tPresent Units\t\ttotal\n");
	for(i=0;i<n;i++)
	{
	float amount=p[i].previous_units-p[i].present_units;
	if(amount>=0 && amount<=100)
	{
		amount=amount*0.80;
	}
	else if(amount>=101 && amount<=200)
	{
		amount=amount*0.90;
	}
	else if(amount>=201 && amount<=300)
	{
		amount=amount*1.00;
	}
	else
	{
		amount=amount*2.00;
	}
	printf("%s\t\t%s\t\t%f\t\t%f\t\t%f\n",p[i].first_name,p[i].last_name,p[i].previous_units,p[i].present_units,amount+100);
    }
}
