#include<stdio.h>
#include<string.h>
main()
{
	float amount;
    float cloth;
	printf("enter the amount\n");
	printf("enter type of cloth\n 1 if mill\n 2 if handloom\n");
	scanf(" %f %f",&amount ,&cloth);
	if(amount<=100)
	{
		if(cloth==1)
		{
			printf("amount is %f",amount);
		}
		else
		{
			printf("amount is %f",amount+(0.05*amount));
		}
	}
	else if(amount>100 && amount<=200)
	{
		if(cloth==1)
		{
			printf("amount is %f",amount+(0.05*amount));
		}
		else
		{
			printf("amount is %f",amount+(0.075*amount));
		}
	}
	else if(amount>200 && amount<=300)
	{
		if(cloth==1)
		{
			printf("amount is %f",amount+(0.075*amount));
		}
		else
		{
			printf("amount is %f",amount+(0.1*amount));
		}
    }
    else
	{
		if(cloth==1)
		{
			printf("amount is %f",amount+(0.1*amount));
		}
		else
		{
			printf("amount is %f",amount+(0.15*amount));
		}
    }
}
