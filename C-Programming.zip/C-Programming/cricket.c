#include<stdio.h>
#include<string.h>
struct batsmen
{
	char name[50];
	int runs;
	int score;
	int balls;
	int toruns;
	int total;
	int ones;
	int twos;
	int threes;
	int fours;
	int sixes;
}ba[10];
struct bowler
{
	char name[50];
	int runsgv;
	int wttk;
	int overs;
	
}bo[10];
void batsmen();
void bowler();
void add();
void search();
void exit();
int i,n,plno,x,choice,nb;
char m,sname[50];
FILE *fp,*fp1;
main()
{
	do
	{
		printf("\n1.batsman\n2.bowler\n3.add\n4.search\n5.exit");
		printf("\n enter your choice");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1: batsmen();
			break;
			case 2: bowler();
		    break;
			case 3: add();
			break;
			case 4: search();
			break;
			case 5: exit();
			break;
		}
		printf("\npress y to continue");
		scanf(" %c",&m);
	}while(m=='y');
}
void batsmen()
{
    printf("Name\t\t\tOnes\tTwoes\tThrees\tFoures\tSixes\tBalls\t");
    i=0;
    fp=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/file.txt","r");
    while(fscanf(fp,"%s%d%d%d%d%d%d",ba[i].name,&ba[i].ones,&ba[i].twos,&ba[i].threes,&ba[i].fours,&ba[i].sixes,&ba[i].balls)!=EOF)
    {
		fprintf(stdout,"\n%s\t\t%d\t%d\t%d\t%d\t%d\t%d",ba[i].name,ba[i].ones,ba[i].twos,ba[i].threes,ba[i].fours,ba[i].sixes,ba[i].balls);
	i++;
	}
    fclose(fp);
}
void bowler()
{
    i=0;
    printf("Name\t\t\tOvers\truns_Given\tWickets");
    fp1=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/file1.txt","r");
    while(fscanf(fp1,"%s%d%d%d",bo[i].name,&bo[i].overs,&bo[i].runsgv,&bo[i].wttk)!=EOF)
    {
		fprintf(stdout,"\n%s\t\t%d\t%d\t\t%d",bo[i].name,bo[i].overs,bo[i].runsgv,bo[i].wttk);
	i++;
	}
    fclose(fp);
}
void add()
{
	printf("Enter 1 for adding batsman\nDetails 2 for adding bowler details:");
	scanf("%d",&n);
	switch(n)
	{
		case 1:printf("enter no.of batsman you want to add:");
		scanf("%d",&nb);
		fp=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/file.txt","a");
		for(i=0;i<nb;i++)
		{
			fscanf(stdin,"%s%d%d%d%d%d%d",ba[i].name,&ba[i].ones,&ba[i].twos,&ba[i].threes,&ba[i].fours,&ba[i].sixes,&ba[i].balls);
			fprintf(fp,"%s\n%d\n%d\n%d\n%d\n%d\n %d",ba[i].name,ba[i].ones,ba[i].twos,ba[i].threes,ba[i].fours,ba[i].sixes,ba[i].balls);
		}
		fclose(fp);
		break;
		case 2:printf("enter no.of bowler you want to add:");
		scanf("%d",&nb);
		fp1=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/file1.txt","a");
		for(i=0;i<nb;i++)
		{
			fscanf(stdin,"%s%d%d%d",bo[i].name,&bo[i].overs,&bo[i].runsgv,&bo[i].wttk);
			fprintf(fp1,"%s\n%d\n%d\n%d\n",bo[i].name,bo[i].overs,bo[i].runsgv,bo[i].wttk);
		}
		fclose(fp1);
		break;
	}
}
void search()
{
	printf("Enter name you want to search:");
	scanf("%s",sname);
	fp=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/file.txt","r");
	i=0;
	while(fscanf(fp,"%s%d%d%d%d%d%d",ba[i].name,&ba[i].ones,&ba[i].twos,&ba[i].threes,&ba[i].fours,&ba[i].sixes,&ba[i].balls)!=EOF)
    {
    	x=strcmp(sname,ba[i].name);
    	if(x==0)
    	{
    		printf("Name\t\t\tOnes\tTwoes\tThrees\tFoures\tSixes\tBalls\t");
		fprintf(stdout,"\n%s\t\t%d\t%d\t%d\t%d\t%d\t%d",ba[i].name,ba[i].ones,ba[i].twos,ba[i].threes,ba[i].fours,ba[i].sixes,ba[i].balls);
	i++;
}
	}
	fclose(fp);
	fp1=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/file1.txt","r");
    while(fscanf(fp1,"%s%d%d%d",bo[i].name,&bo[i].overs,&bo[i].runsgv,&bo[i].wttk)!=EOF)
    {
    	x=strcmp(sname,bo[i].name);
    	if(x==0)
    	{
		printf("Name\t\t\tOvers\truns_Given\tWickets");
		fprintf(stdout,"\n%s\t\t%d\t%d\t\t%d",bo[i].name,bo[i].overs,bo[i].runsgv,bo[i].wttk);
	i++;
}
	}
    fclose(fp);
}
