#include<stdio.h>
main()
{
	int fact,i,n;
	float avg;
	fact=1,i=1;
	printf("Enter number\n");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		fact=fact*i;
	}
	printf("The factorial is %d",fact);
}
