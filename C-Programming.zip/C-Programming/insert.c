#include<stdio.h>
int pos(int,int,int,int []);
main()
{
	int n,a[10],i,s,m;
	printf("Enter no.of elements\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("Enter your position\n");
	scanf("%d",&s);
	printf("Enter element");
	scanf("%d",&m);
	search(n,s,m,a);
}
int search(int n, int s,int m,int a[])
{
	int i;
	for(i=n-1;i>=s;i--)
	{
	a[i+1]=a[i];
    }
	a[s]=m;
    for(i=0;i<n;i++)
	printf("%d",a[i]);
}
