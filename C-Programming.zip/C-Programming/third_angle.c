#include<stdio.h>
 main()
{
  int a,b,c;
  printf("enter the two angles");
  scanf("%d %d",&a,&b);
  c=180-(a+b);
  printf("third angle is %d",c);
}
