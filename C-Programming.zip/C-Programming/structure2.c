#include<stdio.h>
struct student 
{
	char name[10];
	int age;
	float marks;
};
main()
{
	struct student s1;
	printf("Enter studen Details\n");
	scanf("%s %d %f",s1.name,&s1.age,&s1.marks);
	printf("\n--------------------Student Details--------------------\n");
	printf("Name\tAge\tMarks\n");
	printf("%s\t%d\t%f",s1.name,s1.age,s1.marks);
	
}
