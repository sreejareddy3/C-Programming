#include<stdio.h>
main()
{
	int a[20][20],i,n,large=0,m,j;
	printf("Enter order");
    scanf("%d %d",&m,&n);
	printf("Enter elements\n");
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
		scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
		if(large<a[i][j]);
		large=a[i][j];
        }
    }  printf("%d",large);
    //printf("%d",large);
    }
