#include<stdio.h>
int display(int,int);
main()
{
	int x=1,n;
	printf("Enter a number\n");
	scanf("%d",&n);
    display(x,n);
}
int display(int x,int n)
{
	if(x==n+1)
	return;
	else
	printf("%2d",x);
	display(x+1,n);
}
