#include<stdio.h>
main()
{
	int a[3][3],b[3][3],c[3][3],*p,*q,*r,n,m,i,j;
	p=&a[0][0];
	q=&b[0][0];
	r=&c[0][0];
	printf("enter the rows\n");
	scanf("%d" ,&n);
	printf("enter the columns\n");
	scanf("%d",&m);
	printf("Enter 1st matrix\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)

 		{
			scanf("%d",p+(i*m+j));
		}
	}
	printf("Enter 2nd matrix\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)

 		{
			scanf("%d",q+(i*m+j));
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)

 		{
		 *(r+(i*m+j))=*(p+(i*m+j))+*(q+(i*m+j));
		}
	}
		for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%3d",*(r+(i*m+j)));
		}
		printf("\n");
	}
}
