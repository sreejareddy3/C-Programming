#include<stdio.h>
main()
{
	int i,j,a[10][10],m,n;
    printf("Enter order");
    scanf("%d %d",&m,&n);
	printf("Enter elements\n");
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
		scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%3d",a[i][j]);
		}
		printf("\n");
	}
}
