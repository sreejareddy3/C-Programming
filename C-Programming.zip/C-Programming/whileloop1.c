#include<stdio.h>
main()
{
	int x=10;
	while(x<=10 &&x>=0)
	{
		printf("%d  ",x);
		x--;
	}
}

