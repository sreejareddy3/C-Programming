
#include<stdio.h>
#include<string.h>
int compare(char [],char []);
main()
{
	char a[50],b[50];
	int z;
	printf("Enter string 1\n");
	gets(a);
	printf("Enter string 2\n");
	gets(b);
    z=compare(a,b);
    if(z==0)
    printf("Same");
    else
    printf("Not Same");
}
int compare(char a[50],char b[50])
{
	int i,flag=0,j=0;
	for(i=0;a[i]!='\0';i++)
	{
		if(a[i]!=b[i])
		{
			flag=1;
			break;
		}
	}
   return flag;
}
