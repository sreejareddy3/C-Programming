#include<stdio.h>
struct electricity_bill
{
	char first_name[10];
	char last_name[10];
	float previous_units;
	float present_units;
	float total;
}s;
struct electricity_bill read();
main()
{
    s=read();
    display(s);
}
struct electricity_bill read()
{
	printf("enter first name:");
	scanf("%s",s.first_name);
	printf("enter lastname:");
	scanf("%s",s.last_name);
	printf("enter previous units consumed:");
	scanf("%f",&s.previous_units);
	printf("enter present units consumed:");
	scanf("%f",&s.present_units);
	return s;
}
display(struct electricity_bill s)
{
	printf("--------------------Electricity Bill-----------------------------");
	printf("\nFirst Name\tLast Name\tPrevious Units\t\tPresent Units\t\tTotal\n");
	float amt=s.previous_units-s.present_units;
	if(amt>=0 && amt<=100)
	{
		amt=amt*0.80;
	}
	else if(amt>=101 && amt<=200)
	{
		amt=amt*0.90;
	}
	else if(amt>=201 && amt<=300)
	{
		amt=amt*1.00;
	}
	else
	{
		amt=amt*2.00;
	}
	s.total=amt+100;
	printf("%s\t\t%s\t\t%f\t\t%f\t\t%f\n",s.first_name,s.last_name,s.previous_units,s.present_units,s.total);
}





