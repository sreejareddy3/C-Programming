#include<stdio.h>
main()
{
  int a,b;
  printf("enter two values\n");
  scanf("%d %d",&a,&b);
  printf("a=%d b=%d\n",a,b);
  printf("a=%d b=%d",(a+b)-a,(b+a)-b);
}
