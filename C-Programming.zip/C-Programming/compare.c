#include<stdio.h>
#include<string.h>
main()
{
	char str1[50],str2[50],l1=0,l2=0,flag=0,i;
	printf("Enter String 1\n");
	gets(str1);
	printf("Enter String 2\n");
	gets(str2);
	for(i=0;str1[i]!='\0';i++)
	{
	   l1++;	
	}
	for(i=0;str2[i]!='\0';i++)
	{
	   l2++;	
	}
    	for(i=0;str1[i]!='\0';i++)
		{
			if(l1!=l2)
			{
				flag=1;
				break;
			}
		else
		{
			if(str1[i]!=str2[i])
			{
				flag=1;
				break;
			}
		}
	}
   if(flag==0)
   printf("Same");
   else
   printf("Not Same");
}
