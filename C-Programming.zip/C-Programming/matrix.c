#include<stdio.h>
int i,j;
void sum(int,int,int[][10],int[][10]);
main()
{
	int a[10][10],b[10][10],i,n,m;
	printf("enter order of a\n");
	scanf("%d %d",&m,&n);
	printf("Enter matrix1\n");
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	scanf("%d",&a[i][j]);
    }
    printf("Enter matrix2\n");
    for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	scanf("%d",&b[i][j]);
    }
    sum(m,n,a,b);
}
void sum(int m,int n,int a[][10],int b[][10])
{
	int c[10][10];
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
		c[i][j]=a[i][j]+b[i][j];
		printf("%3d",c[i][j]);
	    }
	    printf("\n");
	}
}

