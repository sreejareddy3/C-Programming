#include<stdio.h>
main()
{
	int x,n;
	char t;
	printf("Enter a number\n");
	scanf("%d",&n);
	for(x=1;x<=n;x++)
	{
		printf("%d\n",x);
    }
}

