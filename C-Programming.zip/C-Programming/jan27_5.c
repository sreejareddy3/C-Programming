#include<stdio.h>
main()
{
    int n,sum=0;
    printf("enter a number\n");
    scanf("%d",&n);
    do
    {
        sum=sum+n%10;
        n=n/10;
    }while(n>0);
    printf("sum of individual digits of a number is %d",sum);  
}
