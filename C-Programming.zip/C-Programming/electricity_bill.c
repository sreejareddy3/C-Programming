#include<stdio.h>
struct elcbill 
{
	char fname[50];
	char lname[50];
	float pvu;
	float psu;
	float total;
};
main()
{
	struct elcbill s1;
	printf("Enter first name:");
	scanf("%s",s1.fname);
	printf("Enter last name:");
	scanf("%s",s1.lname);
	printf("Enter your previous units consumed:");
	scanf("%f",&s1.pvu);
	printf("Enter your present units consumed:");
	scanf("%f",&s1.psu);
	float amt=s1.pvu-s1.psu;
	if(amt>=0 && amt<=100)
	amt=amt*0.80;
    else if(amt>100 && amt<=200)
	amt=amt*0.90;
    else if(amt>200 && amt<=300)
	amt=amt*1.0;
    else
	amt=amt*2.0;
	s1.total=amt+100;
    printf("--------------------------Elctricity Bill--------------------------");
    printf("\nFirst Name\tLast Name\tPrevious Units\tpresent Units\tTotal\n");
    printf("%s\t\t%s\t\t%f\t%f\t%f",s1.fname,s1.lname,s1.pvu,s1.psu,s1.total);
}







