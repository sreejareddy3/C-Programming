#include<stdio.h>
main()
{
	char s[10],*p;
	p=&s[0];
	printf("Enter String\n");
	gets(s);
	while(*p!='\0')
	{
		printf("%c",*p);
		p++;
	}
}
