#include<stdio.h>
main()
{
	int count,i,i1,x[20],n;
	printf("Enter n value");
	scanf("%d",&n);
	printf("enter your range");
	for(i=0;i<n;i++)
	{
	scanf("%d",&x[i]);
    }
	for(count=0,i1=1;i<=x[i];i1++)
	{
		if((x[i]%i1)==0)
		{
	     printf("%d",x[i]);
       	}
	}
}
