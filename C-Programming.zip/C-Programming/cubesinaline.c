//cubes of numbers in a line
#include<stdio.h>
main()
{
	int i=1,n,count=1;
	printf("Enter a number\n");
	scanf("%d",&n);
	for(count=1;i<=n;i++)
	{
	    printf("%d %d %d",i,i*i,i*i*i);
	    printf("\n");
	}
}
