#include<stdio.h>
main()
{
	int n,*n1,rev=0,*rev1,a,*a1,*x1,nn,*nn1;
	n1=&n;
	a1=&a;
	rev1=&rev;
	nn1=&nn;
	printf("Enter Number\n");
	scanf("%d",n1);
	*nn1=*n1;
	while(n>0)
	{
		*a1=*n1%10;
		*rev1=(*a1**a1**a1)+*rev1;
		*n1=*n1/10;
	}
	if(*nn1==*rev1)
	printf("Armstrong");
	else
	printf("Not Armstrong");
}
