#include<stdio.h>
main()
{
	int *p,i,n,min=100000000;
	printf("Enter n value:");
	scanf("%d",&n);
	p=(int *)calloc(n,sizeof(int));
	printf("Enter values\n");
	for(i=0;i<n;i++)
	scanf("%d",p+i);
	for(i=0;i<n;i++)
	{
	if(min>*(p+i))
	min=*(p+i);
}
printf("Min:%d",min);
	free(p);
}
