#include<stdio.h>
main()
{
	int a[10][10],i,j,m,n,b[10][10],c[10][10],*m1,*m2,*m3;
	m1=&a[0][0];
	m2=&b[0][0];
	m3=&c[0][0];
	printf("enter order of matrix\n");
	scanf("%d %d",&m,&n);
	printf("enter elements\n");
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		scanf("%d",m1+(i*n+j));
	}
	printf("enter order of second matrix\n");
	scanf("%d %d",&o,&p);
	printf("enter elements\n");
	for(k=0;k<o;k++)
	{
		for(l=0;l<p;l++)
		scanf("%d",m2+(k*p*l));
	}
    if(n==o)
	{	
for(i=0;i<m;i++)
  {
	 for(j=0;j<n;j++)
	{
	  *(m3+(i*n*j))=0;
	  for(k=0;k<n;k++)
	  *(m3+(i*n*j))=*(m3+(i*n*j))+(*(m1+(i*n*j))*(*(m2+(k*p*l))));
    }	
   }
   printf("Matrix-1\n");
   	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		printf("%3d",*(m1+(i*n*j)));
		printf("\n");
	}
	printf("Matrix-2\n");
		for(k=0;k<o;k++)
	{
		for(l=0;l<p;l++)
		printf("%3d",*(m2+(k*p*l)));
		printf("\n");
	}	
	printf("resultant matrix\n");
	for(i=0;i<m;i++)
	{
		for(j=0;j<p;j++)
	    printf("%4d",*(m3+(i*n*j)));
		printf("\n");
	}	
	}
	else
	printf("enter correct order");	
}
