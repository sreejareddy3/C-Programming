#include<stdio.h>
int fact(int);
main()
{
	int n,x;
	printf("Enter number\n");
	scanf("%d",&n);
	x=fact(n);
	printf("factorial=%d",x);
}
int fact(int n)
{
	if(n==1)
	return 1;
	else
	return (n*fact(n-1));
}
