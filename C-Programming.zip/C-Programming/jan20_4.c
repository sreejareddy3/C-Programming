#include<stdio.h>
main()
{
	float sp,cp;
	printf("enter the costing and selling price\n");
	scanf("%f %f",&cp,&sp);
	if(sp>cp)
	{
		printf("Profit\n");
		printf("Profit is %f",sp-cp);
	}
	else
	{
		printf("Loss\n");
		printf("Loss is %f",cp-sp);
	}
}
