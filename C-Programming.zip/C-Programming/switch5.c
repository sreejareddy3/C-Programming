#include<stdio.h>
main()
{
	int dep,n,ts;
	printf("Enter:1 for CSE\n2 for ECE\n3 for EEE\n4 for CIVIL\n");
	scanf("%d",&dep);
	printf("Enter the no.of employees\n");
	scanf("%d",&n);
		switch(dep)
	{
		case 1:ts=n*50000;
		       printf("The total salary is %d",ts);
		       break;
		case 2:ts=n*40000;
		       printf("The total salary is %d",ts);
		       break;
		case 3:ts=n*30000;
		       printf("The total salary is %d",ts);
		       break;
		case 4:ts=n*20000;
		       printf("The total salary is %d",ts);
		       break;	
	}
}
