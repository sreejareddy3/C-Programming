#include<stdio.h>
main()
{
	int a[10],*p[10],n,*n1;
	n1=&n;
	printf("Enter n value");
	scanf("%d",n1);
	int i;
	for(i=0;i<*n1;i++)
	{
		p[i]=&a[i];
	}
	printf("Enter values");
	for(i=0;i<*n1;i++)
	{
		scanf("%d",p[i]);
	}
	for(i=0;i<*n1;i++)
	{
	printf("%d",*p[i]);
	}
}
