#include<stdio.h>
int fact(int);
main()
{
	int n,z;
	printf("Enter the integer:");
	scanf("%d",&n);
	z=fact(n);
	printf("Factorial=%d",z);
}
int fact(int n)
{
	if(n==1)
	return 1;
	else
	return(n*fact(n-1));
}

