#include<stdio.h>
 main()
{
  float a,b,c,d;
  printf("enter y1,y2,x1,x2\n");
  scanf("%f %f %f %f",&a,&b,&c,&d);
  float distance=(d-c)*(d-c)-(b-a)*(b-a);
  printf("distance is %f",distance);
}
