#include<stdio.h>
main()
{
	int m;
	printf("Enter the marks\n");
	scanf("%d",&m);
	if(m>=91)
	{
		printf("A+ Grade");
	}
	else if(m>=81)
	{
		printf("A Grade");
	}
	else if(m>=71)
	{
		printf("B Grade");
	}
	else if(m>=61)
	{
		printf("C Grade");
	}
	else if(m>=51)
	{
		printf("D Grade");
	}
	else if(m>=35)
	{
		printf("E Grade");
	}
	else
	{
		printf("FAIL");
	}
}
