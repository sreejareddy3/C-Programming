#include<stdio.h>
#include<string.h>
main()
{
	int l=0,j=0;
	char str[50],rev[50];
	printf("Enter string\n");
	gets(str);
	int i;
	for(i=0;str[i]!='\0';i++)
	l++;
    for(i=l-1;i>=0;i--)
    {
    rev[j]=str[i];
    j++;
    }
    rev[j]='\0';
    puts(rev);
}
