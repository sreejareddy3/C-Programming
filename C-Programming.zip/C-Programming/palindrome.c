#include<stdio.h>
main()
{
	int n,rev=0,x,m;
	printf("enter a number\n");
	scanf("%d",&n);
	m=n;
	for(rev=0;n>0;n=n/10)
	{
		x=n%10;
		rev=(rev*10)+x;
    }
	if(m==rev)
	{
		printf("Palindrome");
	}
	else
	{
		printf("Not a palindrome");
	}
}
