#include<stdio.h>
main()
{
	int s,d1,d2,a;
	char t;
	float b;
	do{
	printf("Enter:1 for square\n2 for rectangle\n3 for parallelogram\n4 for rhombus\n5 for right angle triangle\n");
	scanf("%d",&s);
	printf("Enter two dimensions\n");
	scanf("%d %d",&d1,&d2);
	switch(s)
	{
	   case 1:a=d1*d2;
	   printf("Area is %d",a);
	   break;
	   case 2:a=d1*d2;
	   printf("Area is %d",a);
	   break;
	   case 3:a=d1*d2;
	   printf("Area is %d",a);
	   break;
	   case 4:b=((float)(d1)*(float)(d2))/2;
	   printf("Area is %f",b);
	   break;
	   case 5:b=((float)(d1)*(float)(d2))/2;;
	   printf("Area is %f",b);
	   break;
	}
	printf("\nPress y to continue");
    scanf(" %c",&t);
    }while(t=='y');	
}
