#include<stdio.h>
int fib(int);
main()
{
	int i,n;
	printf("Enter value\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	printf("%3d",fib(i));
}
int fib(int x)
{
	if((x==0)||(x==1))
	return x;
	else
	return(fib(x-1)+fib(x-2));
}
