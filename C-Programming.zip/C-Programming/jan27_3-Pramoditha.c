#include<stdio.h>
main()
{
	int fact,i,n;
	float avg;
	fact=1,i=1;
	printf("Enter number\n");
	scanf("%d",&n);
	do
	{
		fact=fact*i;
		i++;
	}while(i<=n);
	printf("The factorial is %d",fact);
}
