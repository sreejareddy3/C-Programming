#include<stdio.h>
main()
{
	int a[10],n,*p,*l,pos,*pos1,ele,*ele1;
	printf("Enter n\n");
	scanf("%d",&n);
	int i;
	p=&a[0];
	pos1=&pos;
	ele1=&ele;
	for(i=0;i<n;i++)
	scanf("%d",p+i);
	printf("Enter position");
	scanf("%d",pos1);
	printf("Enter elements");
	scanf("%d",ele1);
	for(i=n-1;i>=(*pos1-1);i--)
	{
	*(p+i+1)=*(p+i);
    }
    *(p+pos-1)=*ele1;
    for(i=0;i<=n;i++)
	printf("%d\n",*(p+i));
}
